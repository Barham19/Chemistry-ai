import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";

export default function ChemistryAIPage() {
  return (
    <div className="min-h-screen bg-blue-100 py-10 px-4">
      <header className="bg-blue-700 text-white py-4 px-6 rounded-xl shadow-md flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Barham Sarkaut Saeed</h1>
        </div>
        <p className="text-white text-sm">
          ويب سايت لحل اسئلة و واجبات في قسم الكيمياء في جامعة كركوك
        </p>
      </header>

      <main className="mt-10 grid gap-6 max-w-4xl mx-auto">
        <Card className="bg-white shadow-xl rounded-2xl p-6">
          <CardContent className="grid gap-4">
            <h2 className="text-xl font-semibold text-center text-blue-800">
              اطرح سؤالك أو ارفع ملف/صورة
            </h2>
            <Input type="file" className="bg-white" />
            <Textarea placeholder="اكتب سؤالك هنا..." className="min-h-[120px] bg-white" />
            <Button className="bg-blue-700 text-white hover:bg-blue-800">
              ارسال السؤال
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-xl rounded-2xl p-6">
          <CardContent>
            <h2 className="text-xl font-semibold text-blue-800 mb-4 text-center">
              الاجابة
            </h2>
            <div className="min-h-[150px] border rounded-lg p-4 bg-gray-50 text-gray-800">
              سيتم عرض الإجابة المدعومة بالذكاء الاصطناعي هنا بشكل دقيق وموثق من الكتب والمراجع الكيميائية.
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
